from django.shortcuts import render

def index(request):
    return render(request, 'index.html')

def comment(request):
    if request.method == 'POST':
        input_text = request.POST.get('inputText', '')
        reversed_text = input_text[::-1]
        return render(request, 'comment.html', {'text': reversed_text})
    else:
        return render(request, 'comment.html')

def converted(request):
    if request.method == 'POST':
        comment_text = request.POST.get('commentText', '')
        reversed_text = comment_text[::-1].upper()
        return render(request, 'converted.html', {'text': reversed_text})
    else:
        return render(request, 'converted.html')